import "./App.css";
declare const App: () => import("react/jsx-runtime").JSX.Element;
export default App;
