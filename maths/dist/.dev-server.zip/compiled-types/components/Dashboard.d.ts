export declare const Dashboard: () => import("react/jsx-runtime").JSX.Element;
