export declare const Router: () => import("react/jsx-runtime").JSX.Element;
